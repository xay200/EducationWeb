<?php
/**
 * Preload Template: chasing dots
 *
 * @package Edu_Press
 */
?>

<div class="sk-chasing-dots">
	<div class="sk-child sk-dot1"></div>
	<div class="sk-child sk-dot2"></div>
</div>
